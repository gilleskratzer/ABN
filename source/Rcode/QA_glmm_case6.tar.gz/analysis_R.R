
if(FALSE){## this block should be commented out on non-local machines
source("../header_code.R");library(INLA);library(lme4);
load("ex7data.RData");## provides ex7.dag.data
load("all.RData");
}

 library(abn)
library(INLA);library(lme4);
load("QA_glmm_case6_data.RData");

m1<-glmer(b1~b2+(1|group),family="binomial",data=ex7.dag.data);

m2<-glm(b1~b2,family="binomial",data=ex7.dag.data);

mydat<-ex7.dag.data;## this data comes with abn drop group variable

mydat.std<-mydat;
## setup distribution list for each node
mydists<-list(
              b1="binomial",
              b2="binomial"
             );


## model where b1<-b2
mydag<-matrix(data=c(
                     0,1, ## b1
                     0,0  ## b2
                     ), byrow=TRUE,ncol=2);

colnames(mydag)<-rownames(mydag)<-names(mydat)[-3];

#myres.c<-fitabn(dag.m=mydag,data.df=mydat,data.dists=mydists,max.mode.error=0,group.var="group",cor.vars=c("slope"));## use C
myres.c.1<-fitabn(dag.m=mydag,data.df=mydat,data.dists=mydists,max.mode.error=0,group.var="group",cor.vars=c("b1"),compute.fixed=TRUE,max.grid.iter=100,
  marginal.node=1,marginal.param=3,variate.vec=seq(0.3,1.5,len=50),n.grid=NULL);

myres.inla<-fitabn(dag.m=mydag,data.df=mydat,data.dists=mydists,max.mode.error=100,group.var="group",cor.vars=c("b1"),compute.fixed=TRUE,n.grid=NULL,std.area=FALSE);## use INLA
 
library(Cairo); 
CairoPNG("QA_glmm_case6_fig1.png", width = 640, height = 480);#postscript("obsall.ps");#,height=10.0,width=11.0,paper="special");
par(mfrow=c(1,1));
par(cex.axis=1.5);par(cex.lab=2.5);par(bg="white");par(fg="black");par(col.axis="black");par(col="black");par(col.main="black");
par(cex.main=2.5);par(col.lab="black");par(las=1);par(xaxs="r");par(yaxs="i");
 plot(spline(myres.c.1$marginals[[1]]),type="l",main="Node slope",xlab="group.precision",ylab="",col="red",xlim=c(0.3,4),ylim=c(0,5));
 lines(myres.inla$marginals$b1[[3]],col="black")
dev.off();

#save.image("all.RData");

mydat.std$b1<-as.numeric(mydat.std$b1)-1;## INLA doesn't like factors as response
r<-try(res<-inla(b1~b2+f(group,model="iid",
                 hyper=list(theta=list(prior="loggamma",param=c(1,5e-05)))),
                 data=mydat.std,family="binomial",control.family=list(hyper = list(prec = list(prior="loggamma",param=c(1,5e-05)))),
                 control.fixed=list(mean.intercept=0,prec.intercept=0.001,mean=0,prec=0.001,compute=TRUE)),silent=TRUE);
 myres.glmer<-glmer(b1 ~ b2 + (1 | group),data=mydat.std,family="binomial");
