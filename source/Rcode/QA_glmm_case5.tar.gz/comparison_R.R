#### compare results between C and INLA
#source("comparison_R.R");
if(FALSE){
rm(list=ls());
if(FALSE){## this block should be commented out on non-local machines
source("../header_code.R");library(INLA);library(lme4);
load("glmm_case5_c.RData");## mycache.c.a
}

load("QA_glmm_case5_data.RData");
library(abn);
library(INLA);library(lme4);
data(Epil);
mydat<-Epil[,c("y","Trt","Age","Ind")];## Epil is from INLA
mydat$Trt<-as.factor(mydat$Trt);
mydat$Ind<-as.factor(mydat$Ind); 
mydat$y<-mydat$y*100;  ## 

## setup distribution list for each node
mydists<-list(y="poisson",
              Trt="binomial",
              Age="gaussian"
             );

mydat.std<-mydat;

## create standardised dataset for comparison with glm
for(i in 1:length(mydists)){if(mydists[[i]]=="gaussian"){## then std data for comparison with glm_case
                                                            mydat.std[,i]<-(mydat.std[,i]-mean(mydat.std[,i]))/sd(mydat.std[,i]);}
}

## create empty matrix which will be filled with nodes as needed
mydag<-matrix(rep(0,(dim(mydat)[2]-1)^2),ncol=dim(mydat)[2]-1);colnames(mydag)<-rownames(mydag)<-names(mydat)[-4];

## loop through each node which differed from INLA by at least 1% and compare with glm() modes
for(i in 1:4){

  mydag[,]<-0;## reset
  node<-mycache.c$child[i];pars<-mycache.c$node.defn[i,];
  if(length(which(pars==1))>0){
  form<-as.formula(paste(colnames(mydag)[node],"~",paste(colnames(mydag)[which(pars==1)],collapse="+",sep=""),"+ (1|Ind)",sep=""));
  } else {form<-as.formula(paste(colnames(mydag)[node],"~1+(1|Ind)",sep=""));}
  family<-mydists[[node]];
  mydag[node,]<-pars;## copy "bad" node into DAG
  myres.c<-fitabn(dag.m=mydag,data.df=mydat,data.dists=mydists,max.mode.error=0,group.var="Ind",cor.vars=c("y"));## use C
  #myres.inla<-fitabn(dag.m=mydag,data.df=mydat,data.dists=mydists,max.mode.error=100,group.var="Ind",cor.vars=c("y"));## use INLA
  r<-try(myres.glmer<-glmer(form,data=mydat.std,family=family));
 if(!(attr(r,"class")=="try-error")){
  myres.glmer<-summary(myres.glmer);
  res.glmer<-c(slot(myres.glmer,"coefs")[,1],1/as.numeric(slot(myres.glmer,"REmat")[,3]));
  if(is.null(names(res.glmer))){names(res.glmer)<-rep("",length(res.glmer));names(res.glmer)[1]<-"(Intercept)";}
  if(family=="gaussian"){names(res.glmer)[-c(1:(length(res.glmer)-2))]<-c("group.precision","residual.precision");
  } else {names(res.glmer)[-c(1:(length(res.glmer)-1))]<-c("group.precision");}

  cat("################ node-parent=",i,"#################\n");
  cat("\n# 1. glmer()\n");print(res.glmer);}
  cat("\n# 2. C\n");print(myres.c$modes[[node]]);
  #if(!(attr(r,"class")=="try-error")){
  #cat("\n# 2b. glmer()-C\n");print(res.glmer-myres.c$modes[[node]]);}
  cat("\n###########################################\n");
}

}

if(TRUE){
rm(list=ls());
source("../header_code.R");library(INLA);library(lme4);
load("glmm_case5_c.RData");## mycache.c.a
data(Epil);
mydat<-Epil[,c("y","Trt","Age","Ind")];## Epil is from INLA
mydat$Trt<-as.factor(mydat$Trt);
mydat$Ind<-as.factor(mydat$Ind); 
mydat$y<-mydat$y*100;  ## 

## setup distribution list for each node
mydists<-list(y="poisson",
              Trt="binomial",
              Age="gaussian"
             );

mydat.std<-mydat;

## create standardised dataset for comparison with glm
for(i in 1:length(mydists)){if(mydists[[i]]=="gaussian"){## then std data for comparison with glm_case
                                                            mydat.std[,i]<-(mydat.std[,i]-mean(mydat.std[,i]))/sd(mydat.std[,i]);}
}

## create empty matrix which will be filled with nodes as needed
mydag<-matrix(rep(0,(dim(mydat)[2]-1)^2),ncol=dim(mydat)[2]-1);colnames(mydag)<-rownames(mydag)<-names(mydat)[-4];

i<-4;
  mydag[,]<-0;## reset
  mydag[node,]<-pars;## copy "bad" node into DAG
  myres.c<-fitabn(dag.m=mydag,data.df=mydat,data.dists=mydists,max.mode.error=0,group.var="Ind",cor.vars=c("y"),compute.fixed=TRUE,max.grid.iter=100);#,compute.fixed=TRUE);## use C
library(Cairo); 
CairoPNG("QA_glmm_case5_fig1.png", width = 640, height = 480);#postscript("obsall.ps");#,height=10.0,width=11.0,paper="special");
par(mfrow=c(2,2));
par(cex.axis=1.5);par(cex.lab=2.5);par(bg="white");par(fg="black");par(col.axis="black");par(col="black");par(col.main="black");
par(cex.main=2.5);par(col.lab="black");par(las=1);par(xaxs="r");par(yaxs="r");
 plot(myres.c$marginals$y[[1]],type="l",main="Node y",xlab="Intercept",ylab="",col="red");
 plot(myres.c$marginals$y[[2]],type="l",main="Node y",xlab="Trt",ylab="",col="red");
 plot(myres.c$marginals$y[[3]],type="l",main="Node y",xlab="Age",ylab="",col="red");
 plot(myres.c$marginals$y[[4]],type="l",main="Node y",xlab="group.precision",ylab="",col="red");
dev.off();
  ## manual fit parameters
  #myres.c.1<-fitabn(dag.m=mydag,data.df=mydat,data.dists=mydists,max.mode.error=0,group.var="group",cor.vars=c("b1"),compute.fixed=TRUE,max.grid.iter=100,
  #marginal.node=1,marginal.param=1,variate.vec=seq(1,4,len=100));## use C
