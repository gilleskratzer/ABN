#source("../header_code.R");
library(abn);
library(INLA);data(Epil);
mydat<-Epil[,c("y","Trt","Age")];## Epil is from INLA
mydat$Trt<-as.factor(mydat$Trt);

## setup distribution list for each node
mydists<-list(y="poisson",
              Trt="binomial",
              Age="gaussian"
             );

## parent limits

## smaller example to allow comparison with INLA 
max.par<-2;## dont use list use 3 parent max for all nodes

## no explicit ban or retain restrictions set so dont need to supply ban or retain matrices

mycache.c<-buildscorecache(data.df=mydat,data.dists=mydists,max.parents=max.par,max.mode.error=0);## only use INLA

save(mycache.c,file="glm_case4_c_A.RData");