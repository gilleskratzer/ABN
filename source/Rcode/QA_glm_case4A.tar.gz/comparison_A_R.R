#### compare results between C and INLA
rm(list=ls());
#source("../header_code.R");
library(abn)
library(INLA);library(lme4);#data(Epil);

load("QA_glm_case4A_data.RData");## provides mycache.c, mycache.inla, Epil

## 1. plot of raw differences, a wide range of values since both poisson, bin and gaus distributions used.
## vast majority as almost identical, but some are rather different
#plot(mycache.inla$mlik-mycache.c$mlik);

## 2. also look at % differences - gives a crude overview
## as 1. so suggests perhaps not just floating point rounding issue e.g. in log transforms
perc<-100*(mycache.c$mlik-mycache.inla$mlik)/mycache.c$mlik;
#plot(perc);
## looks fine except for a bunch which have error about 0.03% which is small but bigger than rest.
library(Cairo);
CairoPNG("QA_glm_case4_fig1.png");#postscript("obsall.ps");#,height=10.0,width=11.0,paper="special");
par(mfrow=c(1,1));
par(mar=c(8.8,8,3.1,3.1));
par(cex.axis=1.5);par(cex.lab=2.5);par(bg="white");par(fg="black");par(col.axis="black");par(col="black");par(col.main="black");
par(cex.main=2.5);par(col.lab="black");par(las=1);par(xaxs="r");par(yaxs="r");
plot(perc,type="n",xlab="",ylab="",axes=F,main="");
mtext("Node-Parent Combination",1,line=3.5,cex=1.5);title("");
points(perc,pch=21,col="blue",bg="green");
par(las=3);
mtext("% Difference in mlik ",2,line=5.5,cex=2.0);par(las=1);
axis(1,padj=0.4,cex.axis=1.5); axis(2);box();
#abline(h=1,lty=1,col="grey");
dev.off();
## 3. get all mliks which are adrift by more than 50% - this is just to catch the massive
## differences
bad<-which(abs(perc)>0.01);

## go through each and check for issues
## 
mydat<-Epil[,c("y","Trt","Age")];## Epil is from INLA
mydat$Trt<-as.factor(mydat$Trt);
mydat.std<-mydat;
## setup distribution list for each node
mydists<-list(y="poisson",
              Trt="binomial",
              Age="gaussian"
             );
## create standardised dataset for comparison with glm
for(i in 1:length(mydists)){if(mydists[[i]]=="gaussian"){## then std data for comparison with glm_case
                                                            mydat.std[,i]<-(mydat.std[,i]-mean(mydat.std[,i]))/sd(mydat.std[,i]);}
}

## create empty matrix which will be filled with nodes as needed
mydag<-matrix(rep(0,dim(mydat)[2]^2),ncol=dim(mydat)[2]);colnames(mydag)<-rownames(mydag)<-names(mydat);

## loop through each node which differed from INLA by at least 1% and compare with glm() modes
for(i in 1:length(bad)){

  mydag[,]<-0;## reset
  node<-mycache.c$child[bad[i]];pars<-mycache.c$node.defn[bad[i],];
  if(length(which(pars==1))>0){
  form<-as.formula(paste(colnames(mydag)[node],"~",paste(colnames(mydag)[which(pars==1)],collapse="+",sep=""),sep=""));
  } else {form<-as.formula(paste(colnames(mydag)[node],"~1",sep=""));}
  family<-mydists[[node]];
  mydag[node,]<-pars;## copy "bad" node into DAG
  myres.c<-fitabn(dag.m=mydag,data.df=mydat,data.dists=mydists,max.mode.error=0);## use C
  myres.inla<-fitabn(dag.m=mydag,data.df=mydat,data.dists=mydists,max.mode.error=100);## use INLA
  myres.glm<-glm(form,data=mydat.std,family=family);
  cat("################ bad=",i,"#################\n");
  cat("\n# 1. glm()\n");print(coef(myres.glm));
  cat("\n# 2. C\n");print(myres.c$modes[[node]]);
  cat("\n# 3. INLA\n");print(myres.inla$modes[[node]]);
  cat("\n###########################################\n");
}

#### Summary. Again, very small differences, but always larger for the Poisson nodes but very small.
#### as in case study 3 the modes seem to be slightly closer using C to glm() than in INLA, for what that's worth.


