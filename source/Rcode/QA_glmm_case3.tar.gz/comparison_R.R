#### compare results between C and INLA
#source("comparison_R.R");
if(FALSE){
rm(list=ls());
if(FALSE){## this block should be commented out on non-local machines
source("../header_code.R");library(INLA);library(lme4);
load("glmm_case3_c.RData");## mycache.c.a
load("glmm_case3_inla.RData");## mycache.inla.a
}
 library(abn)
library(INLA);library(lme4);
load("QA_glmm_case3_data.RData");

## 1. plot of raw differences, a wide range of values since both poisson, bin and gaus distributions used.
## vast majority as almost identical, but some are rather different
#plot(mycache.c$mlik-mycache.inla$mlik);

## 2. also look at % differences - gives a crude overview
## as 1. so suggests perhaps not just floating point rounding issue e.g. in log transforms
perc<-100*(mycache.c$mlik-mycache.inla$mlik)/mycache.c$mlik;
#plot(perc);

library(Cairo);
CairoPNG("QA_glmm_case3_fig1.png");#postscript("obsall.ps");#,height=10.0,width=11.0,paper="special");
par(mfrow=c(1,1));
par(mar=c(8.8,8,3.1,3.1));
par(cex.axis=1.5);par(cex.lab=2.5);par(bg="white");par(fg="black");par(col.axis="black");par(col="black");par(col.main="black");
par(cex.main=2.5);par(col.lab="black");par(las=1);par(xaxs="r");par(yaxs="r");
plot(abs(perc),type="n",xlab="",ylab="",axes=F,main="");
mtext("Node-Parent Combination",1,line=3.5,cex=1.5);title("");
points(abs(perc),pch=21,col="blue",bg="green");
par(las=3);
mtext("% Absolute Difference in mlik ",2,line=5.5,cex=2.0);par(las=1);
abline(h=0.25);
axis(1,padj=0.4,cex.axis=1.25); axis(2);box();
#abline(h=1,lty=1,col="grey");
dev.off();
## generally different but differences are very small
## is this related to the estimation of the hessian?
#plot(mycache.c$hessian.accuracy,mycache.c$mlik-mycache.inla$mlik,log="x")
## no. seems random
CairoPNG("QA_glmm_case3_fig2.png");#postscript("obsall.ps");#,height=10.0,width=11.0,paper="special");
par(mfrow=c(1,1));
par(mar=c(8.8,8,3.1,3.1));
par(cex.axis=1.5);par(cex.lab=2.5);par(bg="white");par(fg="black");par(col.axis="black");par(col="black");par(col.main="black");
par(cex.main=2.5);par(col.lab="black");par(las=1);par(xaxs="r");par(yaxs="r");
plot(mycache.c$hessian.accuracy,perc,type="n",xlab="",ylab="",axes=F,main="",log="x");
mtext("Approximate local error in mlik",1,line=3.5,cex=1.5);title("");
points(mycache.c$hessian.accuracy,perc,pch=21,col="blue",bg="green");
par(las=3);
mtext("% Difference in mlik ",2,line=5.5,cex=2.0);par(las=1);
axis(1,padj=0.4,cex.axis=1.25); axis(2);box();
#abline(h=1,lty=1,col="grey");
dev.off();

## generally different but differences are very small
## is this related to the estimation of the hessian?
#plot(mycache.c$mlik-mycache.inla$mlik,mycache.c$hessian.accuracy)
## no. seems random

## have a look at some of the biggest differences
#sorted.indexes<-order(perc,na.last=FALSE);
bad<-which(abs(perc)>0.25);

library(Cairo);
CairoPNG("QA_glmm_case3_fig3.png");#postscript("obsall.ps");#,height=10.0,width=11.0,paper="special");
par(mfrow=c(1,1));
par(mar=c(8.8,8,3.1,3.1));
par(cex.axis=1.5);par(cex.lab=2.5);par(bg="white");par(fg="black");par(col.axis="black");par(col="black");par(col.main="black");
par(cex.main=2.5);par(col.lab="black");par(las=1);par(xaxs="r");par(yaxs="r");
plot(mycache.c$mlik[bad],mycache.inla$mlik[bad],type="n",xlab="",ylab="",axes=F,main="");
mtext("mlik (internal code)",1,line=3.5,cex=1.5);title("");
points(mycache.c$mlik[bad],mycache.inla$mlik[bad],pch=21,col="blue",bg="green");
par(las=3);
mtext("mlik (INLA) ",2,line=5.5,cex=2.0);par(las=1);
abline(h=0.25);
axis(1,padj=0.4,cex.axis=1.25); axis(2);box();
abline(0,1,lty=1,col="grey");
dev.off();


#bad<-sorted.indexes[seq(length(sorted.indexes),by=-1,len=10)];## top 10


save(bad,mycache.c,mycache.inla,file="tmp.RData");
}
if(FALSE){
source("../header_code.R");
load("tmp.RData");library(lme4);
## go through each and check for issues
## 
mydat<-ex5.dag.data[,c("g1","g2","g3","g4","g5","g6","g7","g8","group")];## take a subset of cols
## this data comes with abn see ?ex1.dag.data
mydat.std<-mydat;
mydists<-list(
              g1="gaussian",
              g2="gaussian",
              g3="gaussian",
              g4="gaussian",
              g5="gaussian",
              g6="gaussian",
              g7="gaussian",
              g8="gaussian"
             
             );
## create standardised dataset for comparison with glm
for(i in 1:length(mydists)){if(mydists[[i]]=="gaussian"){## then std data for comparison with glm_case
                                                            mydat.std[,i]<-(mydat.std[,i]-mean(mydat.std[,i]))/sd(mydat.std[,i]);}
}

## create empty matrix which will be filled with nodes as needed
mydag<-matrix(rep(0,(dim(mydat)[2]-1)^2),ncol=dim(mydat)[2]-1);colnames(mydag)<-rownames(mydag)<-names(mydat)[-9];

## loop through each node which differed from INLA by at least 1% and compare with glm() modes
for(i in 1:length(bad)){

  mydag[,]<-0;## reset
  node<-mycache.c$child[bad[i]];pars<-mycache.c$node.defn[bad[i],];
  if(length(which(pars==1))>0){
  form<-as.formula(paste(colnames(mydag)[node],"~",paste(colnames(mydag)[which(pars==1)],collapse="+",sep=""),"+ (1|group)",sep=""));
  } else {form<-as.formula(paste(colnames(mydag)[node],"~1+(1|group)",sep=""));}
  family<-mydists[[node]];
  mydag[node,]<-pars;## copy "bad" node into DAG
  myres.c<-fitabn(dag.m=mydag,data.df=mydat,data.dists=mydists,max.mode.error=0,group.var="group",cor.vars=c("g1","g2","g3","g4","g5","g6","g7","g8"));## use C
  myres.inla<-fitabn(dag.m=mydag,data.df=mydat,data.dists=mydists,max.mode.error=100,group.var="group",cor.vars=c("g1","g2","g3","g4","g5","g6","g7","g8"));## use INLA
  r<-try(myres.glmer<-glmer(form,data=mydat.std,family=family));
 if(!(attr(r,"class")=="try-error")){
  myres.glmer<-summary(myres.glmer);
  res.glmer<-c(slot(myres.glmer,"coefs")[,1],1/as.numeric(slot(myres.glmer,"REmat")[,3]));
  if(is.null(names(res.glmer))){names(res.glmer)<-rep("",length(res.glmer));names(res.glmer)[1]<-"(Intercept)";}
  names(res.glmer)[-c(1:(length(res.glmer)-2))]<-c("group.precision","residual.precision");
  cat("################ bad=",i,"#################\n");
  cat("\n# 1. glmer()\n");print(res.glmer);}
  cat("\n# 2. C\n");print(myres.c$modes[[node]]);
  if(!(attr(r,"class")=="try-error")){
  cat("\n# 2b. glmer()-C\n");print(res.glmer-myres.c$modes[[node]]);}
  cat("\n# 3. INLA\n");print(myres.inla$modes[[node]]);
if(!(attr(r,"class")=="try-error")){
  cat("\n# 3b. glmer()-INLA\n");print(res.glmer-myres.inla$modes[[node]]);}
  cat("\n###########################################\n");
}

if(FALSE){## a manual compare with raw call to INLA - same results as above - INLA is definitely wrong - see precision estimates 
r<-try(res<-inla(g1~g4+g5+g6+g7+f(group,model="iid",
                 hyper=list(theta=list(prior="loggamma",param=c(1,5e-05)))),
                 data=mydat.std,family="gaussian",control.family=list(hyper = list(prec = list(prior="loggamma",param=c(1,5e-05)))),
                 control.fixed=list(mean.intercept=0,prec.intercept=0.001,mean=0,prec=0.001,compute=TRUE)),silent=TRUE);
 myres.glmer<-glmer(g1 ~ g4 + g5 + g6 + g7 + (1 | group),data=mydat.std,family="gaussian");
}
}

if(TRUE){
## second part if missing mliks
rm(list=ls());
source("../header_code.R");library(INLA);library(lme4);
load("glmm_case3_c.RData");## mycache.c.a
load("glmm_case3_inla.RData");## mycache.inla.a
mymis<-which(is.na(mycache.c$mlik));

library(Cairo);
CairoPNG("QA_glmm_case3_fig4.png");#postscript("obsall.ps");#,height=10.0,width=11.0,paper="special");
par(mfrow=c(1,1));
par(mar=c(8.8,8,3.1,3.1));
par(cex.axis=1.5);par(cex.lab=2.5);par(bg="white");par(fg="black");par(col.axis="black");par(col="black");par(col.main="black");
par(cex.main=2.5);par(col.lab="black");par(las=1);par(xaxs="r");par(yaxs="r");
plot(mycache.inla$mlik,type="n",xlab="",ylab="",axes=F,main="");
mtext("node-parent combination",1,line=3.5,cex=1.5);title("");
points(mycache.inla$mlik,pch=21,col="blue",bg="green");
points(mymis,mycache.inla$mlik[mymis],pch=21,col="red",bg="yellow")
par(las=3);
mtext("mlik (INLA) ",2,line=5.5,cex=2.0);par(las=1);
axis(1,padj=0.4,cex.axis=1.25); axis(2);box();
dev.off();
## 
mydat<-ex5.dag.data[,c("g1","g2","g3","g4","g5","g6","g7","g8","group")];## take a subset of cols
## this data comes with abn see ?ex1.dag.data
mydat.std<-mydat;
mydists<-list(
              g1="gaussian",
              g2="gaussian",
              g3="gaussian",
              g4="gaussian",
              g5="gaussian",
              g6="gaussian",
              g7="gaussian",
              g8="gaussian"
             
             );
## create standardised dataset for comparison with glm
for(i in 1:length(mydists)){if(mydists[[i]]=="gaussian"){## then std data for comparison with glm_case
                                                            mydat.std[,i]<-(mydat.std[,i]-mean(mydat.std[,i]))/sd(mydat.std[,i]);}
}

## create empty matrix which will be filled with nodes as needed
mydag<-matrix(rep(0,(dim(mydat)[2]-1)^2),ncol=dim(mydat)[2]-1);colnames(mydag)<-rownames(mydag)<-names(mydat)[-9];

## loop through each node which differed from INLA by at least 1% and compare with glm() modes
for(i in 1:length(mymis)){

  mydag[,]<-0;## reset
  node<-mycache.c$child[mymis[i]];pars<-mycache.c$node.defn[mymis[i],];
  if(length(which(pars==1))>0){
  form<-as.formula(paste(colnames(mydag)[node],"~",paste(colnames(mydag)[which(pars==1)],collapse="+",sep=""),"+ (1|group)",sep=""));
  } else {form<-as.formula(paste(colnames(mydag)[node],"~1+(1|group)",sep=""));}
  family<-mydists[[node]];
  mydag[node,]<-pars;## copy "bad" node into DAG
  #myres.c<-fitabn(dag.m=mydag,data.df=mydat,data.dists=mydists,max.mode.error=0,group.var="group",cor.vars=c("g1","g2","g3","g4","g5","g6","g7","g8"));## use C
  myres.inla<-fitabn(dag.m=mydag,data.df=mydat,data.dists=mydists,max.mode.error=100,group.var="group",cor.vars=c("g1","g2","g3","g4","g5","g6","g7","g8"));## use INLA
  r<-try(myres.glmer<-glmer(form,data=mydat.std,family=family));
  if(!(attr(r,"class")=="try-error")){
  myres.glmer<-summary(myres.glmer);
  res.glmer<-c(slot(myres.glmer,"coefs")[,1],1/as.numeric(slot(myres.glmer,"REmat")[,3]));
  if(is.null(names(res.glmer))){names(res.glmer)<-rep("",length(res.glmer));names(res.glmer)[1]<-"(Intercept)";}
  names(res.glmer)[-c(1:(length(res.glmer)-2))]<-c("group.precision","residual.precision");}
  cat("################ missing=",i,"#################\n");
  #cat("\n# 1. glmer()\n");print(res.glmer);
  #cat("\n# 2. C\n");print(myres.c$modes[[node]]);
  #cat("\n# 2b. glmer()-C\n");print(res.glmer-myres.c$modes[[node]]);
  #cat("\n# 2. C NA\n");print(myres.c$modes[[node]]);
  cat("\n# 3. INLA\n");print(myres.inla$modes[[node]]);
  cat("\n$ mlik=",myres.inla[[node]],"\n");
  #cat("\n# 3b. glmer()-INLA\n");print(res.glmer-myres.inla$modes[[node]]);
  cat("\n###########################################\n");
}



}

if(FALSE){
##Manual check
source("../header_code.R");

library(lme4);
mydat<-ex5.dag.data[,c("g1","g2","g3","g4","g5","g6","g7","g8","group")];## take a subset of cols
mydat.std<-mydat;
mydists<-list(
              g1="gaussian",
              g2="gaussian",
              g3="gaussian",
              g4="gaussian",
              g5="gaussian",
              g6="gaussian",
              g7="gaussian",
              g8="gaussian"
             
             );
## create standardised dataset for comparison with glm
for(i in 1:length(mydists)){if(mydists[[i]]=="gaussian"){## then std data for comparison with glm_case
                                                            mydat.std[,i]<-(mydat.std[,i]-mean(mydat.std[,i]))/sd(mydat.std[,i]);}
}
max.par<-4;

mycache.c<-build.score.cache(data.df=mydat,data.dists=mydists,group.var="group",
                         cor.vars=c("g1","g2","g3","g4","g5","g6","g7","g8"),
                         max.parents=max.par,
                         verbose=FALSE,centre=TRUE,max.mode.error=0,max.hessian.error=1E-05,dry.run=TRUE);

## create empty matrix which will be filled with nodes as needed
mydag<-matrix(rep(0,(dim(mydat)[2]-1)^2),ncol=dim(mydat)[2]-1);colnames(mydag)<-rownames(mydag)<-names(mydat)[-9];
i<-1;
  mydag[,]<-0;## reset
  #node<-mycache.c$child[bad[i]];pars<-mycache.c$node.defn[bad[i],];
  node<-mycache.c$child[114];pars<-mycache.c$node.defn[114,]
  if(length(which(pars==1))>0){
  form<-as.formula(paste(colnames(mydag)[node],"~",paste(colnames(mydag)[which(pars==1)],collapse="+",sep=""),"+ (1|group)",sep=""));
  } else {form<-as.formula(paste(colnames(mydag)[node],"~1+(1|group)",sep=""));}
  family<-mydists[[node]];
  mydag[node,]<-pars;## copy "bad" node into DAG
  myres.c<-fitabn(dag.m=mydag,data.df=mydat,data.dists=mydists,max.mode.error=0,group.var="group",cor.vars=c("g2"));#,compute.fixed=TRUE);## use C
  myres.inla<-fitabn(dag.m=mydag,data.df=mydat,data.dists=mydists,max.mode.error=100,group.var="group",cor.vars=c("g2"),compute.fixed=TRUE,std.area=FALSE,n.grid=NULL);## use INLA
  myres.glmer<-glmer(form,data=mydat.std,family=family);
  myres.glmer<-summary(myres.glmer);

  ## manual fit parameters
  myres.c.1<-fitabn(dag.m=mydag,data.df=mydat,data.dists=mydists,max.mode.error=0,group.var="group",cor.vars=c("b1"),compute.fixed=TRUE,max.grid.iter=100,
  marginal.node=1,marginal.param=1,variate.vec=seq(1,4,len=100));## use C

  myres.c.2<-fitabn(dag.m=mydag,data.df=mydat,data.dists=mydists,max.mode.error=0,group.var="group",cor.vars=c("b1"),compute.fixed=TRUE,max.grid.iter=100,
  marginal.node=1,marginal.param=2,variate.vec=seq(0,1.5,len=100));## use C

  myres.c.3<-fitabn(dag.m=mydag,data.df=mydat,data.dists=mydists,max.mode.error=0,group.var="group",cor.vars=c("b1"),compute.fixed=TRUE,max.grid.iter=100,
  marginal.node=1,marginal.param=3,variate.vec=seq(-1,1,len=100));## use C

  myres.c.4<-fitabn(dag.m=mydag,data.df=mydat,data.dists=mydists,max.mode.error=0,group.var="group",cor.vars=c("b1"),compute.fixed=TRUE,max.grid.iter=100,
  marginal.node=1,marginal.param=4,variate.vec=seq(-0.5,1.5,len=100));## use C

  myres.c.5<-fitabn(dag.m=mydag,data.df=mydat,data.dists=mydists,max.mode.error=0,group.var="group",cor.vars=c("b1"),compute.fixed=TRUE,max.grid.iter=100,
  marginal.node=1,marginal.param=5,variate.vec=seq(-1,2.0,len=100));## use C

  myres.c.6<-fitabn(dag.m=mydag,data.df=mydat,data.dists=mydists,max.mode.error=0,group.var="group",cor.vars=c("b1"),compute.fixed=TRUE,max.grid.iter=100,
  marginal.node=1,marginal.param=6,variate.vec=seq(0.01,1,len=100));## use C
save.image("all.RData");

 if(FALSE){par(mfrow=c(2,3));
 plot(myres.inla$marginals$b1[[1]],type="l");
 lines(myres.c.1$marginals[[1]],col="red");
 plot(myres.inla$marginals$b1[[2]],type="l");
 lines(myres.c.2$marginals[[1]],col="red");
 plot(myres.inla$marginals$b1[[3]],type="l");
 lines(myres.c.3$marginals[[1]],col="red");
 plot(myres.inla$marginals$b1[[4]],type="l");
 lines(myres.c.4$marginals[[1]],col="red");
 plot(myres.inla$marginals$b1[[5]],type="l");
 lines(myres.c.5$marginals[[1]],col="red");
 plot(myres.inla$marginals$b1[[6]],type="l");
 lines(myres.c.6$marginals[[1]],col="red");
}
}




