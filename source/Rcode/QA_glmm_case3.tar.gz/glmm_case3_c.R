#source("../header_code.R");
library(abn);
mydat<-ex5.dag.data[,c("g1","g2","g3","g4","g5","g6","g7","g8","group")];## take a subset of cols

mydists<-list(
              g1="gaussian",
              g2="gaussian",
              g3="gaussian",
              g4="gaussian",
              g5="gaussian",
              g6="gaussian",
              g7="gaussian",
              g8="gaussian"
             
             );
max.par<-4;

mycache.c<-buildscorecache(data.df=mydat,data.dists=mydists,group.var="group",
                         cor.vars=c("g1","g2","g3","g4","g5","g6","g7","g8"),
                         max.parents=max.par,
                         verbose=FALSE,centre=TRUE,max.mode.error=0,max.hessian.error=1E-04,dry.run=FALSE);

save(mycache.c,file="glmm_case3_c.RData");
#
