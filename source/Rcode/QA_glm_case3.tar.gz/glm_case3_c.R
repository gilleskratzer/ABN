#source("../header_code.R");
library(abn);
mydat<-ex6.dag.data[,-8];## this data comes with abn drop group variable
 
## setup distribution list for each node
mydists<-list(p1="poisson",
              g1="gaussian",
              g2="gaussian",
              b1="binomial",
              b2="binomial",
              g3="gaussian",
              g4="gaussian"
             );

## parent limits

max.par<-3;## dont use list use 3 parent max for all nodes

## no explicit ban or retain restrictions set so dont need to supply ban or retain matrices

mycache.c<-buildscorecache(data.df=mydat,data.dists=mydists,max.parents=max.par,max.mode.error=0);## only use C

save(mycache.c,file="glm_case3_c.RData");