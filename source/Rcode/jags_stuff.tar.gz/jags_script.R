model in model.bug
data in post_params.R
compile, nchains(1)
parameters in inits.R, chain(1)
initialize
update 100000, by(10000)
monitor b2, thin(10)
monitor b3, thin(10)
monitor b4, thin(10)
monitor b5, thin(10)
monitor b6, thin(10)
monitor g1, thin(10)
monitor g2, thin(10)
monitor g3, thin(10)
monitor g4, thin(10)
monitor g5, thin(10)
monitor g6, thin(10)
monitor g7, thin(10)
monitor g8, thin(10)
monitor g9, thin(10)
monitor g10, thin(10)
monitor g11, thin(10)
monitor g12, thin(10)
update 4340, by(434)
coda *, stem("out1")


