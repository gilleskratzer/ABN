#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>

int main(int argc, char *argv[]) {
  int numprocs, rank;
 /* char processor_name[MPI_MAX_PROCESSOR_NAME];*/

  MPI_Init(&argc, &argv);
  MPI_Comm_size(MPI_COMM_WORLD, &numprocs);
  MPI_Comm_rank(MPI_COMM_WORLD, &rank);

if(rank==0){  system("/home/vetadm/flewis/bin/jags script_1.R > log1 2>&1");}
if(rank==1){  system("/home/vetadm/flewis/bin/jags script_2.R > log2 2>&1");}
if(rank==2){  system("/home/vetadm/flewis/bin/jags script_3.R > log3 2>&1");}
if(rank==3){  system("/home/vetadm/flewis/bin/jags script_4.R > log4 2>&1");}
if(rank==4){  system("/home/vetadm/flewis/bin/jags script_5.R > log5 2>&1");}
if(rank==5){  system("/home/vetadm/flewis/bin/jags script_6.R > log6 2>&1");}
if(rank==6){  system("/home/vetadm/flewis/bin/jags script_7.R > log7 2>&1");}
if(rank==7){  system("/home/vetadm/flewis/bin/jags script_8.R > log8 2>&1");}
if(rank==8){  system("/home/vetadm/flewis/bin/jags script_9.R > log9 2>&1");}
if(rank==9){  system("/home/vetadm/flewis/bin/jags script_10.R > log10 2>&1");}
if(rank==10){  system("/home/vetadm/flewis/bin/jags script_11.R > log11 2>&1");}
if(rank==11){  system("/home/vetadm/flewis/bin/jags script_12.R > log12 2>&1");}
if(rank==12){  system("/home/vetadm/flewis/bin/jags script_13.R > log13 2>&1");}
if(rank==13){  system("/home/vetadm/flewis/bin/jags script_14.R > log14 2>&1");}
if(rank==14){  system("/home/vetadm/flewis/bin/jags script_15.R > log15 2>&1");}
if(rank==15){  system("/home/vetadm/flewis/bin/jags script_16.R > log16 2>&1");}
  
printf("Process %d out of %d\n", rank, numprocs);

  MPI_Finalize();

return(0);
}
