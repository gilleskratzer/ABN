#### compare results between C and INLA

##source("../header_code.R");
library(abn);
library(INLA);library(lme4);
load("QA_glm_case2_data.RData");## provides mycache.c, mycache.inla, ex5.dag.data

## 1. plot of raw differences, a wide range of values since both poisson, bin and gaus distributions used.
## vast majority as almost identical, but some are rather different
#plot(mycache.inla$mlik-mycache.c$mlik);

## 2. also look at % differences - gives a crude overview
## as 1. so suggests perhaps not just floating point rounding issue e.g. in log transforms
perc<-100*(mycache.c$mlik-mycache.inla$mlik)/mycache.c$mlik;
#plot(perc);

library(Cairo);
CairoPNG("QA_glm_case2_fig1.png");#postscript("obsall.ps");#,height=10.0,width=11.0,paper="special");
par(mfrow=c(1,1));
par(mar=c(8.8,8,3.1,3.1));
par(cex.axis=1.5);par(cex.lab=2.5);par(bg="white");par(fg="black");par(col.axis="black");par(col="black");par(col.main="black");
par(cex.main=2.5);par(col.lab="black");par(las=1);par(xaxs="r");par(yaxs="r");
plot(perc,type="n",xlab="",ylab="",axes=F,main="");
mtext("Node-Parent Combination",1,line=3.5,cex=1.5);title("");
points(perc,pch=21,col="blue",bg="green");
par(las=3);
mtext("% Difference in mlik ",2,line=5.5,cex=2.0);par(las=1);
axis(1,padj=0.4,cex.axis=1.0); axis(2);box();
#abline(h=1,lty=1,col="grey");
dev.off();
## 3. get all mliks which are adrift by more than 50% - this is just to catch the massive
## differences
bad<-which(abs(perc)>50);

## go through each and check for issues
## 
mydat<-ex5.dag.data[-dim(ex5.dag.data)[2]];## this data comes with abn see ?ex5.dag.data
mydat.std<-mydat;
## setup distribution list for each node
mydists<-list(b1="binomial",
              b2="binomial",
              b3="binomial",
              b4="binomial",
              b5="binomial",
              b6="binomial",
              g1="gaussian",
              g2="gaussian",
              g3="gaussian",
              g4="gaussian", 
              g5="gaussian",
              g6="gaussian",
              g7="gaussian",
              g8="gaussian",
              g9="gaussian",
              g10="gaussian",
              g11="gaussian",
              g12="gaussian");

## create standardised dataset for comparison with glm
for(i in 1:length(mydists)){if(mydists[[i]]=="gaussian"){## then std data for comparison with glm_case
                                                            mydat.std[,i]<-(mydat.std[,i]-mean(mydat.std[,i]))/sd(mydat.std[,i]);}
}

## create empty matrix which will be filled with nodes as needed
mydag<-matrix(rep(0,dim(mydat)[2]^2),ncol=dim(mydat)[2]);colnames(mydag)<-rownames(mydag)<-names(mydat);

## loop through each node which differed from INLA by at least 1% and compare with glm() modes
for(i in 1:length(bad)){

  mydag[,]<-0;## reset
  node<-mycache.c$child[bad[i]];pars<-mycache.c$node.defn[bad[i],];
  form<-as.formula(paste(colnames(mydag)[node],"~",paste(colnames(mydag)[which(pars==1)],collapse="+",sep=""),sep=""));
  family<-mydists[[node]];
  mydag[node,]<-pars;## copy "bad" node into DAG
  myres.c<-fitabn(dag.m=mydag,data.df=mydat,data.dists=mydists,max.mode.error=0);## use C
  myres.inla<-fitabn(dag.m=mydag,data.df=mydat,data.dists=mydists,max.mode.error=100);## use INLA
  myres.glm<-glm(form,data=mydat.std,family=family);
  cat("################ bad=",i,"#################\n");
  cat("\n# 1. glm()\n");print(coef(myres.glm));
  cat("# residual deviance from glm()\n");print(myres.glm$deviance);
  cat("\n# 2. C\n");print(myres.c$modes[[node]]);cat("mlik for node=",myres.c[[node]],"\n");cat("total mlik for DAG=",myres.c$mlik,"\n");
  cat("\n# 3. INLA\n");print(myres.inla$modes[[node]]);cat("mlik for node=",myres.inla[[node]],"\n");cat("total mlik for DAG=",myres.inla$mlik,"\n");
  cat("\n###########################################\n");
}

if(FALSE){## a manual compare with raw call to INLA - same results as above - INLA is definitely wrong - see precision estimates 
r<-try(res<-inla(g4~g2+g11,
                 data=mydat.std,family="gaussian",control.family=list(hyper = list(prec = list(prior="loggamma",param=c(1,5e-05)))),
                 control.fixed=list(mean.intercept=0,prec.intercept=0.001,mean=0,prec=0.001,compute=TRUE)),silent=TRUE);
 myres.glm<-glm(g2 ~ g3 + g4 ,data=mydat.std,family="gaussian");
}
#### Summary. Every single one of these is due to the fact that the model matrix is effectively singular, as can be seen
#### by the residual deviance given by glm() as being zero in every case. C and INLA just give very low mlik values
#### in this case (and massive precision estimate) which seems appropriate as this just says that these models
#### will never be chosen as optimal. So correct.

##############################################################################################################
## PART 2
## now look for more subtle differences, and discard the "singular models"
if(FALSE){
keep.these<-which(mycache.c$mlik> -1e6);
mycache.cp<-mycache.c;## create a copy
mycache.inlap<-mycache.inla;## create a copy
for(i in 1:length(mycache.c)){if(is.null(dim(mycache.cp[[i]]))){mycache.cp[[i]]<-mycache.cp[[i]][keep.these];## have a vector
                                                                mycache.inlap[[i]]<-mycache.inlap[[i]][keep.these];
                              } else {mycache.cp[[i]]<-mycache.cp[[i]][keep.these,];
                                      mycache.inlap[[i]]<-mycache.inlap[[i]][keep.these,];
                                      } ## matrix version
}


## 1. raw differences
plot(mydiff<-mycache.inlap$mlik-mycache.cp$mlik);
print(max(mydiff));print(min(mydiff));
perc<-100*(mycache.cp$mlik-mycache.inlap$mlik)/mycache.cp$mlik;
print(max(perc));print(min(perc));
### all very small so not worth further investigation.
}
