##########################################################################
## build a cache of network scores for using with GLM type model searches
##########################################################################
#source("../header_code.R");## this is just a local surrogate for library(abn)
library(abn);
mydat<-ex2.dag.data;## this data comes with abn see ?ex2.dag.data

## setup distribution list for each node
mydists<-list(b1="binomial",
              g1="gaussian",
              p1="poisson",
              b2="binomial",
              g2="gaussian",
              p2="poisson",
              b3="binomial",
              g3="gaussian",
              p3="poisson",
              b4="binomial",
              g4="gaussian",
              p4="poisson",
              b5="binomial",
              g5="gaussian",
              p5="poisson",
              b6="binomial",
              g6="gaussian",
              p6="poisson"
             );

## set parent limits and banlists etc. 
max.par<-2;## 2 parent max for all nodes
## no explicit ban or retain restrictions 
mycache.inla<-buildscorecache(data.df=mydat,data.dists=mydists,max.parents=max.par,max.mode.error=100);## only use INLA
save(mycache.inla,file="glm_case1_inla.RData");


