#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>

int main(int argc, char *argv[]) {
  int numprocs, rank;
 /* char processor_name[MPI_MAX_PROCESSOR_NAME];*/

  MPI_Init(&argc, &argv);
  MPI_Comm_size(MPI_COMM_WORLD, &numprocs);
  MPI_Comm_rank(MPI_COMM_WORLD, &rank);

if(rank==0){  system("/home/vetadm/flewis/bin/R CMD BATCH --vanilla mp1.R out1");}
if(rank==1){  system("/home/vetadm/flewis/bin/R CMD BATCH --vanilla mp2.R out2");}
if(rank==2){  system("/home/vetadm/flewis/bin/R CMD BATCH --vanilla mp3.R out3");}
if(rank==3){  system("/home/vetadm/flewis/bin/R CMD BATCH --vanilla mp4.R out4");}
if(rank==4){  system("/home/vetadm/flewis/bin/R CMD BATCH --vanilla mp5.R out5");}
if(rank==5){  system("/home/vetadm/flewis/bin/R CMD BATCH --vanilla mp6.R out6");}
if(rank==6){  system("/home/vetadm/flewis/bin/R CMD BATCH --vanilla mp7.R out7");}
if(rank==7){  system("/home/vetadm/flewis/bin/R CMD BATCH --vanilla mp8.R out8");}
if(rank==8){  system("/home/vetadm/flewis/bin/R CMD BATCH --vanilla mp9.R out9");}
if(rank==9){  system("/home/vetadm/flewis/bin/R CMD BATCH --vanilla mp10.R out10");}
if(rank==10){  system("/home/vetadm/flewis/bin/R CMD BATCH --vanilla mp11.R out11");}
if(rank==11){  system("/home/vetadm/flewis/bin/R CMD BATCH --vanilla mp12.R out12");}
if(rank==12){  system("/home/vetadm/flewis/bin/R CMD BATCH --vanilla mp13.R out13");}
if(rank==13){  system("/home/vetadm/flewis/bin/R CMD BATCH --vanilla mp14.R out14");}
if(rank==14){  system("/home/vetadm/flewis/bin/R CMD BATCH --vanilla mp15.R out15");}
if(rank==15){  system("/home/vetadm/flewis/bin/R CMD BATCH --vanilla mp16.R out16");}
if(rank==16){  system("/home/vetadm/flewis/bin/R CMD BATCH --vanilla mp17.R out17");}
if(rank==17){  system("/home/vetadm/flewis/bin/R CMD BATCH --vanilla mp18.R out18");}
if(rank==18){  system("/home/vetadm/flewis/bin/R CMD BATCH --vanilla mp19.R out19");}
if(rank==19){  system("/home/vetadm/flewis/bin/R CMD BATCH --vanilla mp20.R out20");}
if(rank==20){  system("/home/vetadm/flewis/bin/R CMD BATCH --vanilla mp21.R out21");}
if(rank==21){  system("/home/vetadm/flewis/bin/R CMD BATCH --vanilla mp22.R out22");}
if(rank==22){  system("/home/vetadm/flewis/bin/R CMD BATCH --vanilla mp23.R out23");}
if(rank==23){  system("/home/vetadm/flewis/bin/R CMD BATCH --vanilla mp24.R out24");}
if(rank==24){  system("/home/vetadm/flewis/bin/R CMD BATCH --vanilla mp25.R out25");}
if(rank==25){  system("/home/vetadm/flewis/bin/R CMD BATCH --vanilla mp26.R out26");}
if(rank==26){  system("/home/vetadm/flewis/bin/R CMD BATCH --vanilla mp27.R out27");}
if(rank==27){  system("/home/vetadm/flewis/bin/R CMD BATCH --vanilla mp28.R out28");}
if(rank==28){  system("/home/vetadm/flewis/bin/R CMD BATCH --vanilla mp29.R out29");}
if(rank==29){  system("/home/vetadm/flewis/bin/R CMD BATCH --vanilla mp30.R out30");}
if(rank==30){  system("/home/vetadm/flewis/bin/R CMD BATCH --vanilla mp31.R out31");}
if(rank==31){  system("/home/vetadm/flewis/bin/R CMD BATCH --vanilla mp32.R out32");}

  
printf("Process %d out of %d\n", rank, numprocs);

  MPI_Finalize();

return(0);
}
