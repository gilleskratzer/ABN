#!/bin/sh
#$ -N bgm1
#$ -l s_rt=90720
#$ -S /bin/sh
#$ -o  $JOB_NAME_$JOB_ID.out
#$ -j y
#$ -cwd
#$ -R y

. /etc/profile
module load mpi/openmpi/gcc
MPI_HOME=/panfs/panfs0.ften.es.hpcn.uzh.ch/share/software/MPI/OpenMPI/1.4.2
PROGDIR="/home/vetadm/flewis/data/abn_jobs/case_study1"
EXEC="a1.out"
export LD_LIBRARY_PATH=/panfs/panfs0.ften.es.hpcn.uzh.ch/share/software/MPI/OpenMPI/1.4.2/lib:/home/vetadm/flewis/lib:$LD_LIBRARY_PATH

#start the job:
mpirun -np $NSLOTS $PROGDIR/$EXEC
echo "===done==="
# qsub -pe openmpi 32 openmpi_run1.sh
