#source("../header_code.R");
library(abn);
mydat<-ex3.dag.data;## this data comes with abn see ?ex1.dag.data

mydists<-list(b1="binomial",
              b2="binomial",
              b3="binomial",
              b4="binomial",
              b5="binomial",
              b6="binomial",
              b7="binomial",
              b8="binomial",
              b9="binomial",
              b10="binomial",
              b11="binomial",
              b12="binomial",
              b13="binomial"
             );
max.par<-4;

mycache.inla.a<-buildscorecache(data.df=mydat,data.dists=mydists,group.var="group",
                         cor.vars=c("b1","b2","b3","b4","b5","b6","b7","b8","b9","b10","b11","b12","b13"),
                         max.parents=max.par, which.nodes=c(1:4),
                         verbose=FALSE,centre=TRUE,max.mode.error=100);

save(mycache.inla.a,file="glmm_case1_inla_a.RData");
#