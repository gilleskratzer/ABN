#### compare results between C and INLA
#source("comparison_R.R");
if(FALSE){
if(FALSE){## this block should be commented out on non-local machines
rm(list=ls());
#source("../header_code.R");library(INLA);library(lme4);
load("glmm_case1_c_a.RData");## mycache.c.a
load("glmm_case1_c_b.RData");## mycache.c.b
load("glmm_case1_c_c.RData");## mycache.c.c

load("glmm_case1_inla_a.RData");## mycache.inla.a
load("glmm_case1_inla_b.RData");## mycache.inla.b
load("glmm_case1_inla_c.RData");## mycache.inla.c

mycache.c<-mycache.c.a;## create a copy of a
mycache.inla<-mycache.inla.a;## create a copy
for(i in 1:length(mycache.c)){if(is.null(dim(mycache.c[[i]]))){mycache.c[[i]]<-c(mycache.c[[i]],mycache.c.b[[i]],mycache.c.c[[i]]);## have a vector
                                                                mycache.inla[[i]]<-c(mycache.inla[[i]],mycache.inla.b[[i]],mycache.inla.c[[i]]);
                              } else {mycache.c[[i]]<-rbind(mycache.c[[i]],mycache.c.b[[i]],mycache.c.c[[i]]);
                                      mycache.inla[[i]]<-rbind(mycache.inla[[i]],mycache.inla.b[[i]],mycache.inla.c[[i]]);
                                      } ## matrix version
}
} ## end of local block

library(abn)
library(INLA);library(lme4);
load("QA_glmm_case1_data.RData");## provides mycache.c, mycache.inla, ex3.dag.data

## 1. plot of raw differences
mydiff<-(mycache.c$mlik-mycache.inla$mlik);
#plot(mycache.c$hess,mydiff,log="x")
## 2. also look at % differences - gives a crude overview
## as 1. so suggests perhaps not just floating point rounding issue e.g. in log transforms
perc<-100*(mycache.c$mlik-mycache.inla$mlik)/mycache.c$mlik;
#plot(perc);
library(Cairo);
CairoPNG("QA_glmm_case1_fig1.png");#postscript("obsall.ps");#,height=10.0,width=11.0,paper="special");
par(mfrow=c(1,1));
par(mar=c(8.8,8,3.1,3.1));
par(cex.axis=1.5);par(cex.lab=2.5);par(bg="white");par(fg="black");par(col.axis="black");par(col="black");par(col.main="black");
par(cex.main=2.5);par(col.lab="black");par(las=1);par(xaxs="r");par(yaxs="r");
plot(perc,type="n",xlab="",ylab="",axes=F,main="");
mtext("Node-Parent Combination",1,line=3.5,cex=1.5);title("");
points(perc,pch=21,col="blue",bg="green");
par(las=3);
mtext("% Difference in mlik ",2,line=5.5,cex=2.0);par(las=1);
axis(1,padj=0.4,cex.axis=1.25); axis(2);box();
#abline(h=1,lty=1,col="grey");
dev.off();
## generally different but differences are very small
## is this related to the estimation of the hessian
#plot(mycache.c$hessian.accuracy,mycache.c$mlik-mycache.inla$mlik,log="x")
## no. seems random
CairoPNG("QA_glmm_case1_fig2.png");#postscript("obsall.ps");#,height=10.0,width=11.0,paper="special");
par(mfrow=c(1,1));
par(mar=c(8.8,8,3.1,3.1));
par(cex.axis=1.5);par(cex.lab=2.5);par(bg="white");par(fg="black");par(col.axis="black");par(col="black");par(col.main="black");
par(cex.main=2.5);par(col.lab="black");par(las=1);par(xaxs="r");par(yaxs="r");
plot(mycache.c$hessian.accuracy,perc,type="n",xlab="",ylab="",axes=F,main="",log="x");
mtext("Approximate local error in mlik",1,line=3.5,cex=1.5);title("");
points(mycache.c$hessian.accuracy,perc,pch=21,col="blue",bg="green");
par(las=3);
mtext("% Difference in mlik ",2,line=5.5,cex=2.0);par(las=1);
axis(1,padj=0.4,cex.axis=1.25); axis(2);box();
#abline(h=1,lty=1,col="grey");
dev.off();


## have a look at some of the biggest differences
sorted.indexes<-order(abs(perc));## absolute percentage differences

bad<-sorted.indexes[seq(length(sorted.indexes),by=-1,len=10)];## top 10
#bad<-10137;
save(bad,mycache.c,mycache.inla,file="tmp.RData");

source("../header_code.R");library(INLA);library(lme4);
load("tmp.RData");
## go through each and check for issues
## 
mydat<-ex3.dag.data;## this data comes with abn see ?ex1.dag.data
mydat.std<-mydat;
mydists<-list(b1="binomial",
              b2="binomial",
              b3="binomial",
              b4="binomial",
              b5="binomial",
              b6="binomial",
              b7="binomial",
              b8="binomial",
              b9="binomial",
              b10="binomial",
              b11="binomial",
              b12="binomial",
              b13="binomial"
             );
## create standardised dataset for comparison with glm
for(i in 1:length(mydists)){if(mydists[[i]]=="gaussian"){## then std data for comparison with glm_case
                                                            mydat.std[,i]<-(mydat.std[,i]-mean(mydat.std[,i]))/sd(mydat.std[,i]);}
}

## create empty matrix which will be filled with nodes as needed
mydag<-matrix(rep(0,(dim(mydat)[2]-1)^2),ncol=dim(mydat)[2]-1);colnames(mydag)<-rownames(mydag)<-names(mydat)[-dim(mydat)[2]];

## loop through each node which differed from INLA by at least 1% and compare with glm() modes
for(i in 1:length(bad)){
#i<-10;
  mydag[,]<-0;## reset
  node<-mycache.c$child[bad[i]];pars<-mycache.c$node.defn[bad[i],];
  if(length(which(pars==1))>0){
  form<-as.formula(paste(colnames(mydag)[node],"~",paste(colnames(mydag)[which(pars==1)],collapse="+",sep=""),"+ (1|group)",sep=""));
  } else {form<-as.formula(paste(colnames(mydag)[node],"~1+(1|group)",sep=""));}
  family<-mydists[[node]];
  mydag[node,]<-pars;## copy "bad" node into DAG
  myres.c<-fit.abn(dag.m=mydag,data.df=mydat,data.dists=mydists,max.mode.error=0,group.var="group",factor.brent=1E+02,
   cor.vars=c("b1","b2","b3","b4","b5","b6","b7","b8","b9","b10","b11","b12","b13"),max.hessian.error=1E-04,num.intervals.brent=100,hessian.params=c(1E-04,1E-02),max.iters.hessian=100);## use C
  myres.inla<-fit.abn(dag.m=mydag,data.df=mydat,data.dists=mydists,max.mode.error=100,group.var="group",cor.vars=c("b1","b2","b3","b4","b5","b6","b7","b8","b9","b10","b11","b12","b13"));## use INLA
  myres.glmer<-glmer(form,data=mydat.std,family=family);
  myres.glmer<-summary(myres.glmer);
  res.glmer<-c(slot(myres.glmer,"coefs")[,1],1/as.numeric(slot(myres.glmer,"REmat")[3]));names(res.glmer)[length(res.glmer)]<-"group.precision";
  cat("################ bad=",i,"#################\n");
  cat("\n# 1. glmer()\n");print(res.glmer);
  cat("\n# 2. C\n");print(myres.c$modes[[node]]);
  cat("\n# 2b. glmer()-C\n");print(res.glmer-myres.c$modes[[node]]);
  cat("\n# 3. INLA\n");print(myres.inla$modes[[node]]);
  cat("\n# 3b. glmer()-INLA\n");print(res.glmer-myres.inla$modes[[node]]);
  cat("\n###########################################\n");
}

#### Summary. All small differences, modes for INLA differ from lme4 more than C code. 
#### no evidence of systematic differences just lots of small diffs.
}
if(TRUE){

##Manual check - biggest relative difference
source("../header_code.R");mydat<-ex3.dag.data;## this data comes with abn see ?ex1.dag.data
load("tmp.RData");
library(lme4);
mydat.std<-mydat;
mydists<-list(b1="binomial",
              b2="binomial",
              b3="binomial",
              b4="binomial",
              b5="binomial",
              b6="binomial",
              b7="binomial",
              b8="binomial",
              b9="binomial",
              b10="binomial",
              b11="binomial",
              b12="binomial",
              b13="binomial");
## create standardised dataset for comparison with glm
for(i in 1:length(mydists)){if(mydists[[i]]=="gaussian"){## then std data for comparison with glm_case
                                                            mydat.std[,i]<-(mydat.std[,i]-mean(mydat.std[,i]))/sd(mydat.std[,i]);}
}
## create empty matrix which will be filled with nodes as needed
mydag<-matrix(rep(0,(dim(mydat)[2]-1)^2),ncol=dim(mydat)[2]-1);colnames(mydag)<-rownames(mydag)<-names(mydat)[-dim(mydat)[2]];
i<-1;
  mydag[,]<-0;## reset
  node<-mycache.c$child[bad[i]];pars<-mycache.c$node.defn[bad[i],];
  if(length(which(pars==1))>0){
  form<-as.formula(paste(colnames(mydag)[node],"~",paste(colnames(mydag)[which(pars==1)],collapse="+",sep=""),"+ (1|group)",sep=""));
  } else {form<-as.formula(paste(colnames(mydag)[node],"~1+(1|group)",sep=""));}
  family<-mydists[[node]];
  mydag[node,]<-pars;## copy "bad" node into DAG
#### VERY WEIRD need to check gvalue at mode for b6|intercept - giving nonsense!
  #myres.c<-fit.abn(dag.m=mydag,data.df=mydat,data.dists=mydists,max.mode.error=0,group.var="group",cor.vars=c("b7"),max.hessian.error=1E-04);#compute.fixed=TRUE,n.grid=NULL,std.area=FALSE)
  #marginal.node=6,marginal.param=3,variate.vec=seq(-0.8,0.8,len=2));## use C
  myres.inla<-fit.abn(dag.m=mydag,data.df=mydat,data.dists=mydists,max.mode.error=100,group.var="group",cor.vars=c("b10"),compute.fixed=TRUE,std.area=FALSE,n.grid=NULL);## use INLA
  #myres.glmer<-glmer(form,data=mydat.std,family=family);
  #myres.glmer<-summary(myres.glmer);
  #res.glmer<-c(slot(myres.glmer,"coefs")[,1],1/as.numeric(slot(myres.glmer,"REmat")[3]));names(res.glmer)[length(res.glmer)]<-"group.precision";

  ## manual fit parameters
  if(TRUE){myres.c.1<-fit.abn(dag.m=mydag,data.df=mydat,data.dists=mydists,max.mode.error=0,group.var="group",cor.vars=c("b10"),compute.fixed=TRUE,n.grid=NULL,
  marginal.node=10,marginal.param=1,variate.vec=seq(-1.5,1.0,len=100),
                   max.hessian.error=1E-04,num.intervals.brent=100,std.area=TRUE);## use C
  save.image("all_1.RData");
  }
  if(FALSE){myres.c.2<-fit.abn(dag.m=mydag,data.df=mydat,data.dists=mydists,max.mode.error=0,group.var="group",cor.vars=c("b10"),compute.fixed=TRUE,n.grid=NULL,
  marginal.node=10,marginal.param=2,variate.vec=seq(-2,0.0,len=100),max.hessian.error=1E-04,num.intervals.brent=100,std.area=TRUE);## use C
save.image("all_2.RData");
  }
  if(FALSE){myres.c.3<-fit.abn(dag.m=mydag,data.df=mydat,data.dists=mydists,max.mode.error=0,group.var="group",cor.vars=c("b10"),compute.fixed=TRUE,n.grid=NULL,
  marginal.node=10,marginal.param=3,variate.vec=seq(-2,0,len=100),max.hessian.error=1E-04,num.intervals.brent=100,std.area=TRUE);## use C
save.image("all_3.RData");
  }
  if(FALSE){myres.c.4<-fit.abn(dag.m=mydag,data.df=mydat,data.dists=mydists,max.mode.error=0,group.var="group",cor.vars=c("b10"),compute.fixed=TRUE,n.grid=NULL,
  marginal.node=10,marginal.param=4,variate.vec=seq(0.35,2.5,len=100),max.hessian.error=1E-04,num.intervals.brent=100,std.area=TRUE);## use C
save.image("all_4.RData");
  }
  if(FALSE){myres.c.5<-fit.abn(dag.m=mydag,data.df=mydat,data.dists=mydists,max.mode.error=0,group.var="group",cor.vars=c("b10"),compute.fixed=TRUE,n.grid=NULL,
  marginal.node=10,marginal.param=5,variate.vec=seq(0.5,2.5,len=100),max.hessian.error=1E-04,num.intervals.brent=100,std.area=TRUE);## use C
save.image("all_5.RData");
  }
  if(FALSE){myres.c.6<-fit.abn(dag.m=mydag,data.df=mydat,data.dists=mydists,max.mode.error=0,group.var="group",cor.vars=c("b10"),compute.fixed=TRUE,n.grid=NULL,
  marginal.node=10,marginal.param=6,variate.vec=seq(0.01,1,len=100),max.hessian.error=1E-04,num.intervals.brent=100,std.area=TRUE);## use C
save.image("all_6.RData");
  }
#save.image("all.RData");
 if(FALSE){par(mfrow=c(2,3));
 plot(myres.inla$marginals$b10[[1]],type="l");
 lines(myres.c.1$marginals[[1]],col="red");
 plot(myres.inla$marginals$b10[[2]],type="l");
 lines(myres.c.2$marginals[[1]],col="red");
 plot(myres.inla$marginals$b10[[3]],type="l");
 lines(myres.c.3$marginals[[1]],col="red");
 plot(myres.inla$marginals$b10[[4]],type="l");
 lines(myres.c.4$marginals[[1]],col="red");
 plot(myres.inla$marginals$b10[[5]],type="l");
 lines(myres.c.5$marginals[[1]],col="red");
 plot(myres.inla$marginals$b10[[6]],type="l",xlim=c(0,1));
 lines(myres.c.6$marginals[[1]],col="red");}

if(FALSE){
load("all_1.RData");load("all_2.RData");load("all_3.RData");load("all_4.RData");load("all_5.RData");load("all_6.RData");

## std.area - save running above again
sum1<-sum(diff(myres.c.1$marginals[[1]][,1])[1]*myres.c.1$marginals[[1]][,2]);
sum2<-sum(diff(myres.c.2$marginals[[1]][,1])[1]*myres.c.2$marginals[[1]][,2]);
sum3<-sum(diff(myres.c.3$marginals[[1]][,1])[1]*myres.c.3$marginals[[1]][,2]);
sum4<-sum(diff(myres.c.4$marginals[[1]][,1])[1]*myres.c.4$marginals[[1]][,2]);
sum5<-sum(diff(myres.c.5$marginals[[1]][,1])[1]*myres.c.5$marginals[[1]][,2]);
sum6<-sum(diff(myres.c.6$marginals[[1]][,1])[1]*myres.c.6$marginals[[1]][,2]);


CairoPNG("QA_glmm_case1_fig3.png", width = 640, height = 480);#postscript("obsall.ps");#,height=10.0,width=11.0,paper="special");
par(mfrow=c(2,3));
par(cex.axis=1.5);par(cex.lab=2.5);par(bg="white");par(fg="black");par(col.axis="black");par(col="black");par(col.main="black");
par(cex.main=2.5);par(col.lab="black");par(las=1);par(xaxs="r");par(yaxs="r");
 plot(myres.inla$marginals$b10[[1]][,1],myres.inla$marginals$b10[[1]][,2],type="l",main="Node b10",xlab="Intercept",ylab="");
 lines(myres.c.1$marginals[[1]][,1],myres.c.1$marginals[[1]][,2]/sum1,col="red");
 plot(myres.inla$marginals$b10[[2]][,1],myres.inla$marginals$b10[[2]][,2],type="l",main="Node b10",xlab="b5",ylab="");
 lines(myres.c.2$marginals[[1]][,1],myres.c.2$marginals[[1]][,2]/sum2,col="red");
 plot(myres.inla$marginals$b10[[3]][,1],myres.inla$marginals$b10[[3]][,2],type="l",main="Node b10",xlab="b6",ylab="");
 lines(myres.c.3$marginals[[1]][,1],myres.c.3$marginals[[1]][,2]/sum3,col="red");
 plot(myres.inla$marginals$b10[[4]][,1],myres.inla$marginals$b10[[4]][,2],type="l",main="Node b10",xlab="b7",ylab="");
 lines(myres.c.4$marginals[[1]][,1],myres.c.4$marginals[[1]][,2]/sum4,col="red");
 plot(myres.inla$marginals$b10[[5]][,1],myres.inla$marginals$b10[[5]][,2],type="l",main="Node b10",xlab="b9",ylab="");
 lines(myres.c.5$marginals[[1]][,1],myres.c.5$marginals[[1]][,2]/sum5,col="red");
 plot(myres.inla$marginals$b10[[6]][,1],myres.inla$marginals$b10[[6]][,2],type="l",xlim=c(0,1),main="Node b10", xlab="group.precision",ylab="");
 lines(myres.c.6$marginals[[1]][,1],myres.c.6$marginals[[1]][,2]/sum6,col="red");
dev.off();

}


}


