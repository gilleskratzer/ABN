#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>

int main(int argc, char *argv[]) {
  int numprocs, rank;
 /* char processor_name[MPI_MAX_PROCESSOR_NAME];*/

  MPI_Init(&argc, &argv);
  MPI_Comm_size(MPI_COMM_WORLD, &numprocs);
  MPI_Comm_rank(MPI_COMM_WORLD, &rank);

if(rank==0){  system("/home/vetadm/flewis/bin/R CMD BATCH --vanilla init_order_2par.R out1");}
if(rank==1){  system("/home/vetadm/flewis/bin/R CMD BATCH --vanilla init_order_3par.R out2");}
if(rank==2){  system("/home/vetadm/flewis/bin/R CMD BATCH --vanilla init_order_4par.R out3");}
if(rank==3){  system("/home/vetadm/flewis/bin/R CMD BATCH --vanilla init_order_5par.R out4");}
if(rank==4){  system("/home/vetadm/flewis/bin/R CMD BATCH --vanilla init_order_6par.R out5");}
if(rank==5){  system("/home/vetadm/flewis/bin/R CMD BATCH --vanilla init_order_7par.R out6");}
if(rank==6){  system("/home/vetadm/flewis/bin/R CMD BATCH --vanilla init_order_8par.R out7");}
if(rank==7){  system("/home/vetadm/flewis/bin/R CMD BATCH --vanilla init_order_9par.R out8");}


  
printf("Process %d out of %d\n", rank, numprocs);

  MPI_Finalize();

return(0);
}
